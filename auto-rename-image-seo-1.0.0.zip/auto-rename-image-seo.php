<?php /* Auto Rename Image SEO v.0.0 */
